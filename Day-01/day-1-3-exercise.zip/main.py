#Write your code below this line 👇
print(len(input("How length your name")))








